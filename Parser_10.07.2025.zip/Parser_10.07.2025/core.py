from bs4 import BeautifulSoup
import requests
import pandas as pd
#import time  time не используется в этой версии, но может быть полезен для добавления задержек между запросами.

csv_b = [] #список csv для хранения данных о цитатах
url = "https://quotes.toscrape.com/"#всталяем url сайта который будем парсить
response = requests.get(url) #пингуем сайт который будем извлекать
html_content = response.text #извлекаем html в текстовое содержимое

soup = BeautifulSoup(html_content,"lxml") #создаем обьект BeatifulSoup и используем парсер lxml который лучше чем встроенный html_parser

quotes = soup.find_all("div", class_ = "quote") #находим все HTML-элементы <div> с классом quote. Каждый такой элемент содержит одну цитату со всей информацией о ней.

for q in quotes: #цикл для перебора и обработки каждой найденной цитатой
    quot = q.find("span", class_="text").text #конвертирование в текст сразу
    name = q.find("small",class_ = "author").text 
    tag_meta = q.find("meta", class_ = "keywords") 
    tags = tag_meta["content"] #извлечение отдельного нужного атрибута

    csv_b.append({
        "Quotes": quot,
        "Author": name,
        "Tags": tags
    }) #добавляем данные в список
    print(f"Цитата - {quot}, Создатель цитаты - {name}, Теги - {tags}") #окончательный вывод всей основной информации о цитате
df = pd.DataFrame(csv_b) #создаем dataframe из списка словарей
df.to_csv("quotes.csv", index=False) #сохраняем dataframe в csv файл
print("Был создан CSV файл (quotes.csv) для дальнейшего изучения")
#работа над данным парсером была окончена 18.07.25, спасибо за внимание